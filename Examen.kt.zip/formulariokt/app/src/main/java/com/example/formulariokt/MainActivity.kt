import android.content.ContentValues
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.formulariokt.R

class MainActivity : AppCompatActivity() {
    private lateinit var txtNombre: EditText
    private lateinit var txtEdad: EditText
    private lateinit var txtTelefono: EditText
    private lateinit var txtCiudad: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtNombre = findViewById(R.id.txtNombre)
        txtEdad = findViewById(R.id.txtEdad)
        txtTelefono = findViewById(R.id.txtTelefono)
        txtCiudad = findViewById(R.id.txtCiudad)
    }

    fun insertar(view: View) {
        val con = SQLiteHelper(this, "personasDB", null, 1)
        val baseDatos = con.writableDatabase

        val nombre = txtNombre.text.toString()
        val edad = txtEdad.text.toString()
        val telefono = txtTelefono.text.toString()
        val ciudad = txtCiudad.text.toString()

        if (nombre.isNotEmpty() && edad.isNotEmpty() && telefono.isNotEmpty() && ciudad.isNotEmpty()) {
            val registro = ContentValues().apply {
                put("nombre", nombre)
                put("edad", edad.toIntOrNull() ?: 0) // Evita errores si no se introduce un número
                put("telefono", telefono)
                put("ciudad", ciudad)
            }

            val resultado = baseDatos.insert("personas", null, registro)
            baseDatos.close()

            if (resultado != -1L) {
                txtNombre.setText("")
                txtEdad.setText("")
                txtTelefono.setText("")
                txtCiudad.setText("")
                Toast.makeText(this, "Registro insertado correctamente", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Error al insertar el registro", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(this, "Todos los campos deben estar llenos", Toast.LENGTH_LONG).show()
        }
    }
}
